CREATE DATABASE LaMiaTacosDB;
USE LaMiaTacosDB;

-- Tabla de Usuarios
CREATE TABLE Usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(255),
    correo VARCHAR(100) NOT NULL UNIQUE,
    contraseña VARCHAR(255) NOT NULL,
    codigo_administrador VARCHAR(15) UNIQUE,
    es_administrador BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (codigo_administrador) REFERENCES Codigos_Admin(codigo) -- Relación con Codigos_Admin
);

-- Tabla de Roles (Para manejar permisos)
CREATE TABLE Roles (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    nombre_rol VARCHAR(50) NOT NULL
);

-- Relación de Usuarios con Roles
CREATE TABLE Usuarios_Roles (
    id_usuario INT,
    id_rol INT,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_rol) REFERENCES Roles(id_rol)
);

-- Tabla de Productos
CREATE TABLE Productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre_producto VARCHAR(100) NOT NULL,
    tipo_producto ENUM('taco', 'salsa', 'bebida') NOT NULL,
    precio DECIMAL(6, 2) NOT NULL
);

-- Tabla de Inventario
CREATE TABLE Inventario (
    id_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT,
    stock_actual INT NOT NULL,
    stock_minimo INT NOT NULL,
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Tabla de Historial de Inventario (Movimientos de stock)
CREATE TABLE Historial_Inventario (
    id_historial_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT,
    cantidad_movimiento INT NOT NULL, -- Positivo para entrada, negativo para salida
    tipo_movimiento ENUM('compra', 'venta', 'ajuste') NOT NULL,
    fecha_movimiento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Tabla de Pedidos
CREATE TABLE Pedidos (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    fecha_pedido DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    monto_total DECIMAL(10, 2) NOT NULL,
    estado_pedido ENUM('recibido', 'preparando', 'listo', 'entregado') NOT NULL,
    programado_para DATETIME,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Detalles de Pedido
CREATE TABLE Detalles_Pedido (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    id_producto INT,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(6, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Tabla de Carritos
CREATE TABLE Carritos (
    id_carrito INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Detalles de Carrito
CREATE TABLE Detalles_Carrito (
    id_detalle_carrito INT AUTO_INCREMENT PRIMARY KEY,
    id_carrito INT,
    id_producto INT,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(6, 2) NOT NULL,
    FOREIGN KEY (id_carrito) REFERENCES Carritos(id_carrito),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Tabla de Recompensas
CREATE TABLE Recompensas (
    id_recompensa INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    puntos_acumulados INT NOT NULL DEFAULT 0,
    puntos_canjeados INT NOT NULL DEFAULT 0,
    fecha_ultima_compra DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Historial de Recompensas
CREATE TABLE Historial_Recompensas (
    id_transaccion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    puntos_otorgados INT NOT NULL,
    puntos_canjeados INT NOT NULL DEFAULT 0,
    fecha_transaccion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    descripcion VARCHAR(255),
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Historial de Compras
CREATE TABLE Historial_Compra (
    id_historial INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_producto INT,
    fecha_compra DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- Tabla de Comentarios
CREATE TABLE Comentarios (
    id_comentario INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    calificacion INT NOT NULL CHECK (calificacion >= 1 AND calificacion <= 5),
    comentario TEXT,
    FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido)
);

-- Tabla de Pagos
CREATE TABLE Pagos (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    metodo_pago ENUM('tarjeta', 'paypal', 'otro'),
    token_pago VARCHAR(255), -- Token de pago generado por el proveedor
    estado_pago ENUM('pendiente', 'exitoso', 'fallido') NOT NULL,
    fecha_pago DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido)
);

-- Tabla de Créditos de Tienda
CREATE TABLE Creditos_Tienda (
    id_credito INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    monto_credito DECIMAL(10, 2) NOT NULL,
    motivo VARCHAR(255), -- Ej. "Cambio de producto", "Problema con el pedido"
    fecha_otorgado DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    usado BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Auditoría (Historial de acciones)
CREATE TABLE Auditoria (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    accion VARCHAR(255) NOT NULL, -- Ej. "Actualización de pedido", "Modificación de carrito"
    tabla_afectada VARCHAR(100),
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Notificaciones
CREATE TABLE Notificaciones (
    id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    mensaje TEXT NOT NULL,
    fecha_enviada DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    leida BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario)
);

-- Tabla de Cupones
CREATE TABLE Cupones (
    id_cupon INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(100) NOT NULL UNIQUE,
    descuento DECIMAL(6, 2) NOT NULL, -- Porcentaje o monto de descuento
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT 1
);

-- Relación de Cupones con Usuarios (Cupones utilizados)
CREATE TABLE Cupones_Usuarios (
    id_usuario INT,
    id_cupon INT,
    fecha_uso DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario),
    FOREIGN KEY (id_cupon) REFERENCES Cupones(id_cupon)
);

-- Tabla para almacenar los códigos de administrador
CREATE TABLE Codigos_Admin (
    id_codigo INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(15) NOT NULL UNIQUE, -- Código de administrador único
    estado ENUM('disponible', 'usado') NOT NULL DEFAULT 'disponible' -- Estado del código
);
