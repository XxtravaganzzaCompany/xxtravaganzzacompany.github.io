package javaConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class lamiatacosBD {
    // Cambia estos valores según tu configuración
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/LaMiaTacosDB";
    private static final String USER = "root";
    private static final String PASSWORD = "123456789";

    // Método para obtener una conexión
    public static Connection getConnection() {
        Connection connection = null;
        try {
            // Cargar el driver de MySQL (opcional en JDBC 4.0 y posterior)
            Class.forName("com.mysql.cj.jdbc.Driver"); // Asegúrate de que el driver esté en el classpath
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver de MySQL. Asegúrate de tener el conector JDBC en el classpath.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error al establecer la conexión: " + e.getMessage());
            e.printStackTrace();
        }
        return connection; // Retorna la conexión (puede ser nula si hubo un error)
    }

    // Método para cerrar la conexión (a utilizar cuando termines con la conexión)
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión cerrada correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
