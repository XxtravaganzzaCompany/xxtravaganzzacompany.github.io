package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javaConnection.lamiatacosBD; // Importa tu clase de conexión

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String codigoAdmin = request.getParameter("codigo_administrador");
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("contraseña");

        boolean loginExitoso = false; // Variable para verificar si el login es exitoso

        try (Connection conn = lamiatacosBD.getConnection()) { // Obtener conexión a la base de datos
            String sql = "SELECT * FROM Usuarios WHERE codigo_administrador = ? AND correo = ? AND contrasena = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, codigoAdmin);
            stmt.setString(2, correo);
            stmt.setString(3, contrasena);
            
            ResultSet rs = stmt.executeQuery();

            // Si se encuentra el usuario
            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("usuario", correo); // Guardar el correo en la sesión
                loginExitoso = true; // Marcar el login como exitoso

                // Redirigir a la página de éxito (holaprueba.html)
                response.sendRedirect("holaprueba.html");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Imprimir el error en la consola
            request.setAttribute("error", "Error al conectar a la base de datos. Inténtalo de nuevo.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return; // Salir del método
        }

        // Si las credenciales son incorrectas
        if (!loginExitoso) {
            request.setAttribute("error", "Credenciales inválidas. Inténtalo de nuevo.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
